package com.example.product;

public class Userdata {

    public static abstract class NewUserInfo
    {
        public static final String name = "officer_name";
        public static final String reference = "case_reference";
        public static final String type = "crime_type";
        public static final String date = "crime_date";
        public static final String time = "crime_time";
        public static final String location = "crime_location";
        public static final String description = "crime_desc";
        public static final String Table_name = "crime_info";



    }
}
